package tarekWebApp.jee;

public class LoginService {
	public boolean validateUser(String user, String password) {
		return user.equalsIgnoreCase("manar") && password.equals("dummy");
	}

}